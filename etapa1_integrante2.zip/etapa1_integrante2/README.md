# Lan House Byte 2000 - Checkpoint 2

**Disciplina:** Algoritmos e Pensamento Computacional

## Integrantes e módulos

|Módulo|Integrante|Struct|
|-|-|-|
|1. Clientes|Alexander Guimarães Gallotti Moreira, 47364548|`Cliente`|
|2. Computadores|João Felipe Alves Silva, 48302422|`Computador`|
|3. Lanchonete / Produtos|Nicolas Bryan de Oliveira Camargo, 48070068|`Produto`|
|4. Sessões e Relatórios|Guilherme Henrique Bueno, 47290391|`Sessao`|

## O que foi feito neste checkpoint

* **Cadastro e listagem em funções separadas:** cada módulo tem as funções `cadastrar...`, `listar...`, `buscar...`, `editar...` e `remover...`, todas fora do `main()` e com `// Autor:` no cabeçalho.
* **Relatórios (Módulo 4):**
  * Computador mais utilizado (soma dos minutos de todas as sessões).
  * Cliente VIP (cliente com mais minutos de uso).
  * Sessões de um cliente específico (com o total gasto).
* **Ordenação (Bubble Sort), uma em cada módulo:**
  * Clientes em ordem alfabética.
  * Computadores pelo valor da hora (mais barato primeiro).
  * Produtos pelo preço (mais barato primeiro).
  * Sessões pelo valor (mais cara primeiro).
* **Próximos passos:** dividir o código em arquivos `.h` e salvar os dados em arquivos `.txt`.

## Como executar

Abra o arquivo `main.c` no Dev-C++ e pressione F11 para compilar e executar.

Dica para testar: cadastre primeiro clientes (Módulo 1) e computadores (Módulo 2), porque a sessão (Módulo 4) precisa dos dois.
