#include <stdio.h>
#include <string.h>

// ============================================================================
// LAN HOUSE BYTE 2000 - CHECKPOINT 2
// Cadastro, listagem, edicao, remocao, relatorios e ordenacao
// Equipe: [Alexander, Guilherme Henrique, Jo�o Felipe, Nicolas Bryan]
// ============================================================================

// ============================================================================
// PARTE 1: MODELAGEM DE DADOS (ESCOPO GLOBAL - 1 STRUCT POR INTEGRANTE)
// ============================================================================

// 1. Perspectiva do Integrante A: Clientes da Lan House
struct Cliente {
    int idCliente;
    char nome[50];
    char telefone[20];
    float saldoHoras; // horas compradas e ainda nao usadas
    int ativo; // 1 = Ativo, 0 = Removido
};

struct Cliente listaClientes[50];
int totalClientes = 0;

// 2. Perspectiva do Integrante B: Computadores da Lan House
struct Computador {
    int idComputador;
    char descricao[40]; // exemplo: PC Gamer 01
    float valorHora; // preco cobrado por hora de uso
    int ocupado; // 1 = Em uso, 0 = Livre
    int ativo; // 1 = Ativo, 0 = Removido
};

struct Computador listaComputadores[50];
int totalComputadores = 0;

// 3. Perspectiva do Integrante C: Produtos da Lanchonete
struct Produto {
    int idProduto;
    char nome[40];
    char categoria[20]; // exemplo: Bebida, Salgado
    float preco;
    int quantidadeEstoque;
};

struct Produto estoqueProdutos[50];
int totalProdutos = 0;
int proximoIdProduto = 1; // proximo ID a ser usado (so aumenta, para nao repetir ID depois de remover)

// 4. Perspectiva do Integrante D: Sessoes de uso e Relatorios
struct Sessao {
    int idSessao;
    int idClienteSessao;
    int idComputadorSessao;
    int minutosUsados;
    float valorTotal;
};

struct Sessao historicoSessoes[50];
int totalSessoes = 0;
int proximoIdSessao = 1; // proximo ID a ser usado (so aumenta, para nao repetir ID depois de cancelar)


// ============================================================================
// PARTE 2: FUNCOES DE INTERFACE E MODULOS DE CADA INTEGRANTE
// ============================================================================

// ----------------------------------------------------------------------------
// FUNCAO COMUM DA EQUIPE: Cabecalho do sistema
// Autor: [Integrante A - Alexander Guimar�es Gallotti Moreira, 47364548]
// ----------------------------------------------------------------------------
void exibirCabecalho() {
    printf("\n======================================================\n");
    printf("      LAN HOUSE BYTE 2000 - SISTEMA DE GESTAO         \n");
    printf("======================================================\n");
}


// ----------------------------------------------------------------------------
// MODULO 1: PERSPECTIVA DE CLIENTES
// Autor: [Integrante A - Alexander Guimar�es Gallotti Moreira, 47364548]
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Procura um cliente ATIVO pelo ID e devolve a posicao dele no vetor.
// Se nao encontrar, devolve -1.
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
int buscarIndiceCliente(int id) {
    int i;
    for (i = 0; i < totalClientes; i++) {
        if (listaClientes[i].idCliente == id && listaClientes[i].ativo == 1) {
            return i; // achou: devolve a posicao
        }
    }
    return -1; // percorreu o vetor todo e nao achou
}

// ----------------------------------------------------------------------------
// Cadastra um novo cliente na proxima posicao livre do vetor.
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void cadastrarCliente() {
    if (totalClientes >= 50) {
        printf("\n[ERRO] Limite de 50 clientes atingido!\n");
    } else {
        // O ID e gerado automaticamente. Como a remocao so marca ativo = 0,
        // totalClientes nunca diminui e o ID nunca se repete.
        listaClientes[totalClientes].idCliente = totalClientes + 1;

        printf("\nNome do cliente: ");
        scanf(" %[^\n]", listaClientes[totalClientes].nome); // le o nome com espacos
        printf("Telefone: ");
        scanf(" %[^\n]", listaClientes[totalClientes].telefone);
        printf("Saldo inicial de horas (ex: 2.5): ");
        scanf("%f", &listaClientes[totalClientes].saldoHoras);
        listaClientes[totalClientes].ativo = 1;

        printf("\nCliente cadastrado com sucesso! ID gerado: %d\n", listaClientes[totalClientes].idCliente);
        totalClientes++;
    }
}

// ----------------------------------------------------------------------------
// Lista todos os clientes ativos.
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void listarClientes() {
    int i;
    int encontrou = 0; // 0 = nenhum cliente mostrado, 1 = mostrou pelo menos um

    printf("\n--- LISTA DE CLIENTES ---\n");
    for (i = 0; i < totalClientes; i++) {
        if (listaClientes[i].ativo == 1) {
            printf("ID: %d | Nome: %s | Telefone: %s | Saldo: %.1f horas\n",
                   listaClientes[i].idCliente, listaClientes[i].nome,
                   listaClientes[i].telefone, listaClientes[i].saldoHoras);
            encontrou = 1;
        }
    }
    if (encontrou == 0) {
        printf("Nenhum cliente cadastrado.\n");
    }
}

// ----------------------------------------------------------------------------
// Busca um cliente pelo ID e mostra os dados dele.
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void buscarCliente() {
    int id;
    int indice;

    printf("\nDigite o ID do cliente: ");
    scanf("%d", &id);
    indice = buscarIndiceCliente(id);

    if (indice == -1) {
        printf("\n[ERRO] Cliente nao encontrado!\n");
    } else {
        printf("\n--- CLIENTE ENCONTRADO ---\n");
        printf("ID: %d\n", listaClientes[indice].idCliente);
        printf("Nome: %s\n", listaClientes[indice].nome);
        printf("Telefone: %s\n", listaClientes[indice].telefone);
        printf("Saldo de horas: %.1f\n", listaClientes[indice].saldoHoras);
    }
}

// ----------------------------------------------------------------------------
// Edita nome, telefone e saldo de horas de um cliente.
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void editarCliente() {
    int id;
    int indice;

    printf("\nDigite o ID do cliente que deseja editar: ");
    scanf("%d", &id);
    indice = buscarIndiceCliente(id);

    if (indice == -1) {
        printf("\n[ERRO] Cliente nao encontrado!\n");
    } else {
        printf("Editando: %s\n", listaClientes[indice].nome);
        printf("Novo nome: ");
        scanf(" %[^\n]", listaClientes[indice].nome);
        printf("Novo telefone: ");
        scanf(" %[^\n]", listaClientes[indice].telefone);
        printf("Novo saldo de horas: ");
        scanf("%f", &listaClientes[indice].saldoHoras);
        printf("\nCliente atualizado com sucesso!\n");
    }
}

// ----------------------------------------------------------------------------
// Remove um cliente (remocao logica: apenas marca ativo = 0).
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void removerCliente() {
    int id;
    int indice;

    printf("\nDigite o ID do cliente que deseja remover: ");
    scanf("%d", &id);
    indice = buscarIndiceCliente(id);

    if (indice == -1) {
        printf("\n[ERRO] Cliente nao encontrado!\n");
    } else {
        listaClientes[indice].ativo = 0;
        printf("\nCliente %s removido com sucesso!\n", listaClientes[indice].nome);
    }
}

// ----------------------------------------------------------------------------
// ORDENACAO: coloca os clientes em ordem alfabetica (Bubble Sort).
// Autor: [Integrante A - Alexander]
// ----------------------------------------------------------------------------
void ordenarClientesPorNome() {
    int i, j;
    struct Cliente aux; // variavel auxiliar para fazer a troca

    for (i = 0; i < totalClientes - 1; i++) {
        for (j = 0; j < totalClientes - 1 - i; j++) {
            // strcmp devolve um numero maior que 0 se o primeiro nome vem depois no alfabeto
            if (strcmp(listaClientes[j].nome, listaClientes[j + 1].nome) > 0) {
                aux = listaClientes[j];
                listaClientes[j] = listaClientes[j + 1];
                listaClientes[j + 1] = aux;
            }
        }
    }
    printf("\nClientes ordenados por nome (A a Z)!\n");
    listarClientes();
}

// ----------------------------------------------------------------------------
// Submenu do Modulo 1
// Autor: [Integrante A - Alexander ]
// ----------------------------------------------------------------------------
void moduloClientes() {
    int opcaoCliente;
    do {
        printf("\n--- [MODULO 1: GESTAO DE CLIENTES (Integrante A)] ---\n");
        printf("1. Cadastrar Novo Cliente\n");
        printf("2. Listar Todos os Clientes\n");
        printf("3. Editar Dados ou Saldo de Horas de Cliente\n");
        printf("4. Remover Cliente\n");
        printf("5. Buscar Cliente por ID\n");
        printf("6. [ORDENACAO] Listar Clientes em Ordem Alfabetica\n");
        printf("0. Voltar ao Menu Principal\n");
        printf("Escolha uma acao: ");
        opcaoCliente = -1; // comeca invalida: se digitarem uma letra, cai no default
        scanf("%d", &opcaoCliente);
        while (getchar() != '\n') { } // joga fora o que sobrou digitado (letras e o Enter)

        switch (opcaoCliente) {
            case 1:
                cadastrarCliente();
                break;
            case 2:
                listarClientes();
                break;
            case 3:
                editarCliente();
                break;
            case 4:
                removerCliente();
                break;
            case 5:
                buscarCliente();
                break;
            case 6:
                ordenarClientesPorNome();
                break;
            case 0:
                printf("\nRetornando ao menu principal...\n");
                break;
            default:
                printf("\n[ERRO] Opcao invalida no Modulo de Clientes!\n");
        }
    } while (opcaoCliente != 0);
}


// ----------------------------------------------------------------------------
// MODULO 2: PERSPECTIVA DE COMPUTADORES
// Autor: [Integrante B - Jo�o Felipe Alves Silva, 48302422]
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Procura um computador ATIVO pelo ID e devolve a posicao dele no vetor.
// Se nao encontrar, devolve -1.
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
int buscarIndiceComputador(int id) {
    int i;
    for (i = 0; i < totalComputadores; i++) {
        if (listaComputadores[i].idComputador == id && listaComputadores[i].ativo == 1) {
            return i;
        }
    }
    return -1;
}

// ----------------------------------------------------------------------------
// Cadastra um novo computador (ele comeca Livre).
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void cadastrarComputador() {
    if (totalComputadores >= 50) {
        printf("\n[ERRO] Limite de 50 computadores atingido!\n");
    } else {
        // Mesmo raciocinio do cliente: a remocao e logica, entao o ID nao se repete.
        listaComputadores[totalComputadores].idComputador = totalComputadores + 1;

        printf("\nDescricao do computador (ex: PC Gamer 01): ");
        scanf(" %[^\n]", listaComputadores[totalComputadores].descricao);
        printf("Valor da hora (ex: 5.50): ");
        scanf("%f", &listaComputadores[totalComputadores].valorHora);
        listaComputadores[totalComputadores].ocupado = 0; // todo computador novo comeca livre
        listaComputadores[totalComputadores].ativo = 1;

        printf("\nComputador cadastrado com sucesso! ID gerado: %d\n", listaComputadores[totalComputadores].idComputador);
        totalComputadores++;
    }
}

// ----------------------------------------------------------------------------
// Lista todos os computadores ativos e mostra se estao Livres ou Em uso.
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void listarComputadores() {
    int i;
    int encontrou = 0;

    printf("\n--- LISTA DE COMPUTADORES ---\n");
    for (i = 0; i < totalComputadores; i++) {
        if (listaComputadores[i].ativo == 1) {
            printf("ID: %d | %s | R$ %.2f por hora | Status: ",
                   listaComputadores[i].idComputador, listaComputadores[i].descricao,
                   listaComputadores[i].valorHora);
            if (listaComputadores[i].ocupado == 1) {
                printf("Em uso\n");
            } else {
                printf("Livre\n");
            }
            encontrou = 1;
        }
    }
    if (encontrou == 0) {
        printf("Nenhum computador cadastrado.\n");
    }
}

// ----------------------------------------------------------------------------
// Busca um computador pelo ID e mostra os dados dele.
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void buscarComputador() {
    int id;
    int indice;

    printf("\nDigite o ID do computador: ");
    scanf("%d", &id);
    indice = buscarIndiceComputador(id);

    if (indice == -1) {
        printf("\n[ERRO] Computador nao encontrado!\n");
    } else {
        printf("\n--- COMPUTADOR ENCONTRADO ---\n");
        printf("ID: %d\n", listaComputadores[indice].idComputador);
        printf("Descricao: %s\n", listaComputadores[indice].descricao);
        printf("Valor da hora: R$ %.2f\n", listaComputadores[indice].valorHora);
        if (listaComputadores[indice].ocupado == 1) {
            printf("Status: Em uso\n");
        } else {
            printf("Status: Livre\n");
        }
    }
}

// ----------------------------------------------------------------------------
// Edita descricao, valor da hora e status (Livre / Em uso) de um computador.
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void editarComputador() {
    int id;
    int indice;

    printf("\nDigite o ID do computador que deseja editar: ");
    scanf("%d", &id);
    indice = buscarIndiceComputador(id);

    if (indice == -1) {
        printf("\n[ERRO] Computador nao encontrado!\n");
    } else {
        printf("Editando: %s\n", listaComputadores[indice].descricao);
        printf("Nova descricao: ");
        scanf(" %[^\n]", listaComputadores[indice].descricao);
        printf("Novo valor da hora: ");
        scanf("%f", &listaComputadores[indice].valorHora);

        // repete a pergunta ate o usuario digitar 0 ou 1
        do {
            printf("Status (0 = Livre, 1 = Em uso): ");
            scanf("%d", &listaComputadores[indice].ocupado);
        } while (listaComputadores[indice].ocupado != 0 && listaComputadores[indice].ocupado != 1);

        printf("\nComputador atualizado com sucesso!\n");
    }
}

// ----------------------------------------------------------------------------
// Remove um computador (remocao logica: apenas marca ativo = 0).
// Nao deixa remover um computador que esta em uso.
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void removerComputador() {
    int id;
    int indice;

    printf("\nDigite o ID do computador que deseja remover: ");
    scanf("%d", &id);
    indice = buscarIndiceComputador(id);

    if (indice == -1) {
        printf("\n[ERRO] Computador nao encontrado!\n");
    } else if (listaComputadores[indice].ocupado == 1) {
        printf("\n[ERRO] Nao e possivel remover um computador que esta em uso!\n");
    } else {
        listaComputadores[indice].ativo = 0;
        printf("\nComputador %s removido com sucesso!\n", listaComputadores[indice].descricao);
    }
}

// ----------------------------------------------------------------------------
// ORDENACAO: coloca os computadores do menor para o maior valor da hora (Bubble Sort).
// Autor: [Integrante B - Jo�o Felipe]
// ----------------------------------------------------------------------------
void ordenarComputadoresPorValor() {
    int i, j;
    struct Computador aux;

    for (i = 0; i < totalComputadores - 1; i++) {
        for (j = 0; j < totalComputadores - 1 - i; j++) {
            if (listaComputadores[j].valorHora > listaComputadores[j + 1].valorHora) {
                aux = listaComputadores[j];
                listaComputadores[j] = listaComputadores[j + 1];
                listaComputadores[j + 1] = aux;
            }
        }
    }
    printf("\nComputadores ordenados por valor da hora (mais barato primeiro)!\n");
    listarComputadores();
}

// ----------------------------------------------------------------------------
// Submenu do Modulo 2
// Autor: [Integrante B - Jo�o Felipe Alves Silva, 48302422]
// ----------------------------------------------------------------------------
void moduloComputadores() {
    int opcaoComputador;
    do {
        printf("\n--- [MODULO 2: GESTAO DE COMPUTADORES (Integrante B)] ---\n");
        printf("1. Cadastrar Novo Computador\n");
        printf("2. Listar Computadores / Ver Status (Livre ou Em Uso)\n");
        printf("3. Editar Descricao, Valor da Hora ou Status\n");
        printf("4. Remover Computador\n");
        printf("5. Buscar Computador por ID\n");
        printf("6. [ORDENACAO] Listar Computadores por Valor da Hora\n");
        printf("0. Voltar ao Menu Principal\n");
        printf("Escolha uma acao: ");
        opcaoComputador = -1; // comeca invalida: se digitarem uma letra, cai no default
        scanf("%d", &opcaoComputador);
        while (getchar() != '\n') { } // joga fora o que sobrou digitado (letras e o Enter)

        switch (opcaoComputador) {
            case 1:
                cadastrarComputador();
                break;
            case 2:
                listarComputadores();
                break;
            case 3:
                editarComputador();
                break;
            case 4:
                removerComputador();
                break;
            case 5:
                buscarComputador();
                break;
            case 6:
                ordenarComputadoresPorValor();
                break;
            case 0:
                printf("\nRetornando ao menu principal...\n");
                break;
            default:
                printf("\n[ERRO] Opcao invalida no Modulo de Computadores!\n");
        }
    } while (opcaoComputador != 0);
}


// ----------------------------------------------------------------------------
// MODULO 3: PERSPECTIVA DE PRODUTOS DA LANCHONETE
// Autor: [Integrante C - Nicolas Bryan de Oliveira Camargo, 48070068]
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Procura um produto pelo ID e devolve a posicao dele no vetor.
// Se nao encontrar, devolve -1.
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
int buscarIndiceProduto(int id) {
    int i;
    for (i = 0; i < totalProdutos; i++) {
        if (estoqueProdutos[i].idProduto == id) {
            return i;
        }
    }
    return -1;
}

// ----------------------------------------------------------------------------
// Cadastra um novo produto da lanchonete.
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void cadastrarProduto() {
    if (totalProdutos >= 50) {
        printf("\n[ERRO] Limite de 50 produtos atingido!\n");
    } else {
        // Aqui a remocao apaga o produto do vetor (totalProdutos diminui),
        // por isso usamos um contador separado para o ID nunca se repetir.
        estoqueProdutos[totalProdutos].idProduto = proximoIdProduto;
        proximoIdProduto++;

        printf("\nNome do produto: ");
        scanf(" %[^\n]", estoqueProdutos[totalProdutos].nome);
        printf("Categoria (ex: Bebida, Salgado, Doce): ");
        scanf(" %[^\n]", estoqueProdutos[totalProdutos].categoria);
        printf("Preco (ex: 4.50): ");
        scanf("%f", &estoqueProdutos[totalProdutos].preco);
        printf("Quantidade em estoque: ");
        scanf("%d", &estoqueProdutos[totalProdutos].quantidadeEstoque);

        printf("\nProduto cadastrado com sucesso! ID gerado: %d\n", estoqueProdutos[totalProdutos].idProduto);
        totalProdutos++;
    }
}

// ----------------------------------------------------------------------------
// Lista todos os produtos da lanchonete.
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void listarProdutos() {
    int i;

    printf("\n--- PRODUTOS DA LANCHONETE ---\n");
    if (totalProdutos == 0) {
        printf("Nenhum produto cadastrado.\n");
    } else {
        for (i = 0; i < totalProdutos; i++) {
            printf("ID: %d | %s | Categoria: %s | R$ %.2f | Estoque: %d\n",
                   estoqueProdutos[i].idProduto, estoqueProdutos[i].nome,
                   estoqueProdutos[i].categoria, estoqueProdutos[i].preco,
                   estoqueProdutos[i].quantidadeEstoque);
        }
    }
}

// ----------------------------------------------------------------------------
// Busca um produto pelo ID e mostra os dados dele.
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void buscarProduto() {
    int id;
    int indice;

    printf("\nDigite o ID do produto: ");
    scanf("%d", &id);
    indice = buscarIndiceProduto(id);

    if (indice == -1) {
        printf("\n[ERRO] Produto nao encontrado!\n");
    } else {
        printf("\n--- PRODUTO ENCONTRADO ---\n");
        printf("ID: %d\n", estoqueProdutos[indice].idProduto);
        printf("Nome: %s\n", estoqueProdutos[indice].nome);
        printf("Categoria: %s\n", estoqueProdutos[indice].categoria);
        printf("Preco: R$ %.2f\n", estoqueProdutos[indice].preco);
        printf("Estoque: %d unidades\n", estoqueProdutos[indice].quantidadeEstoque);
    }
}

// ----------------------------------------------------------------------------
// Edita o preco e a quantidade em estoque de um produto.
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void editarProduto() {
    int id;
    int indice;

    printf("\nDigite o ID do produto que deseja editar: ");
    scanf("%d", &id);
    indice = buscarIndiceProduto(id);

    if (indice == -1) {
        printf("\n[ERRO] Produto nao encontrado!\n");
    } else {
        printf("Editando: %s\n", estoqueProdutos[indice].nome);
        printf("Novo preco: ");
        scanf("%f", &estoqueProdutos[indice].preco);
        printf("Nova quantidade em estoque: ");
        scanf("%d", &estoqueProdutos[indice].quantidadeEstoque);
        printf("\nProduto atualizado com sucesso!\n");
    }
}

// ----------------------------------------------------------------------------
// Remove um produto do vetor (remocao fisica: puxa os proximos uma posicao
// para tras e diminui o total).
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void removerProduto() {
    int id;
    int indice;
    int i;

    printf("\nDigite o ID do produto que deseja remover: ");
    scanf("%d", &id);
    indice = buscarIndiceProduto(id);

    if (indice == -1) {
        printf("\n[ERRO] Produto nao encontrado!\n");
    } else {
        printf("\nProduto %s removido com sucesso!\n", estoqueProdutos[indice].nome);
        // cada produto depois do removido "anda" uma posicao para tras
        for (i = indice; i < totalProdutos - 1; i++) {
            estoqueProdutos[i] = estoqueProdutos[i + 1];
        }
        totalProdutos--;
    }
}

// ----------------------------------------------------------------------------
// ORDENACAO: coloca os produtos do menor para o maior preco (Bubble Sort).
// Autor: [Integrante C - Nicolas Bryan]
// ----------------------------------------------------------------------------
void ordenarProdutosPorPreco() {
    int i, j;
    struct Produto aux;

    for (i = 0; i < totalProdutos - 1; i++) {
        for (j = 0; j < totalProdutos - 1 - i; j++) {
            if (estoqueProdutos[j].preco > estoqueProdutos[j + 1].preco) {
                aux = estoqueProdutos[j];
                estoqueProdutos[j] = estoqueProdutos[j + 1];
                estoqueProdutos[j + 1] = aux;
            }
        }
    }
    printf("\nProdutos ordenados por preco (mais barato primeiro)!\n");
    listarProdutos();
}

// ----------------------------------------------------------------------------
// Submenu do Modulo 3
// Autor: [Integrante C - Nicolas Bryan de Oliveira Camargo, 48070068]
// ----------------------------------------------------------------------------
void moduloProdutos() {
    int opcaoProduto;
    do {
        printf("\n--- [MODULO 3: LANCHONETE E ESTOQUE (Integrante C)] ---\n");
        printf("1. Cadastrar Novo Produto\n");
        printf("2. Listar Todos os Produtos\n");
        printf("3. Editar Preco ou Estoque do Produto\n");
        printf("4. Remover Produto\n");
        printf("5. Buscar Produto por ID\n");
        printf("6. [ORDENACAO] Listar Produtos por Preco\n");
        printf("0. Voltar ao Menu Principal\n");
        printf("Escolha uma acao: ");
        opcaoProduto = -1; // comeca invalida: se digitarem uma letra, cai no default
        scanf("%d", &opcaoProduto);
        while (getchar() != '\n') { } // joga fora o que sobrou digitado (letras e o Enter)

        switch (opcaoProduto) {
            case 1:
                cadastrarProduto();
                break;
            case 2:
                listarProdutos();
                break;
            case 3:
                editarProduto();
                break;
            case 4:
                removerProduto();
                break;
            case 5:
                buscarProduto();
                break;
            case 6:
                ordenarProdutosPorPreco();
                break;
            case 0:
                printf("\nRetornando ao menu principal...\n");
                break;
            default:
                printf("\n[ERRO] Opcao invalida no Modulo de Produtos!\n");
        }
    } while (opcaoProduto != 0);
}


// ----------------------------------------------------------------------------
// MODULO 4: PERSPECTIVA DE SESSOES E RELATORIOS
// Autor: [Integrante D - Guilherme Henrique Bueno, 47290391]
// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// Procura uma sessao pelo ID e devolve a posicao dela no vetor.
// Se nao encontrar, devolve -1.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
int buscarIndiceSessao(int id) {
    int i;
    for (i = 0; i < totalSessoes; i++) {
        if (historicoSessoes[i].idSessao == id) {
            return i;
        }
    }
    return -1;
}

// ----------------------------------------------------------------------------
// Registra uma sessao: cruza um Cliente com um Computador e calcula o valor.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void registrarSessao() {
    int idCliente, idComputador, minutos;
    int indiceCliente, indiceComputador;
    float valor;

    if (totalSessoes >= 50) {
        printf("\n[ERRO] Limite de 50 sessoes atingido!\n");
    } else {
        printf("\nID do cliente: ");
        scanf("%d", &idCliente);
        indiceCliente = buscarIndiceCliente(idCliente); // funcao do Modulo 1

        printf("ID do computador: ");
        scanf("%d", &idComputador);
        indiceComputador = buscarIndiceComputador(idComputador); // funcao do Modulo 2

        if (indiceCliente == -1) {
            printf("\n[ERRO] Cliente nao encontrado! Cadastre o cliente no Modulo 1.\n");
        } else if (indiceComputador == -1) {
            printf("\n[ERRO] Computador nao encontrado! Cadastre o computador no Modulo 2.\n");
        } else {
            // repete a pergunta ate o usuario digitar um tempo maior que zero
            do {
                printf("Minutos usados: ");
                scanf("%d", &minutos);
            } while (minutos <= 0);

            // usamos 60.0 (e nao 60) para a divisao ter casas decimais
            valor = (minutos / 60.0) * listaComputadores[indiceComputador].valorHora;

            historicoSessoes[totalSessoes].idSessao = proximoIdSessao;
            historicoSessoes[totalSessoes].idClienteSessao = idCliente;
            historicoSessoes[totalSessoes].idComputadorSessao = idComputador;
            historicoSessoes[totalSessoes].minutosUsados = minutos;
            historicoSessoes[totalSessoes].valorTotal = valor;
            totalSessoes++;
            proximoIdSessao++;

            printf("\nSessao registrada com sucesso!\n");
            printf("Cliente: %s | Computador: %s | %d minutos | Total: R$ %.2f\n",
                   listaClientes[indiceCliente].nome, listaComputadores[indiceComputador].descricao,
                   minutos, valor);
        }
    }
}

// ----------------------------------------------------------------------------
// Lista todas as sessoes registradas.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void listarSessoes() {
    int i;

    printf("\n--- HISTORICO DE SESSOES ---\n");
    if (totalSessoes == 0) {
        printf("Nenhuma sessao registrada.\n");
    } else {
        for (i = 0; i < totalSessoes; i++) {
            printf("Sessao %d | ID Cliente: %d | ID Computador: %d | %d minutos | R$ %.2f\n",
                   historicoSessoes[i].idSessao, historicoSessoes[i].idClienteSessao,
                   historicoSessoes[i].idComputadorSessao, historicoSessoes[i].minutosUsados,
                   historicoSessoes[i].valorTotal);
        }
    }
}

// ----------------------------------------------------------------------------
// Cancela (estorna) uma sessao: apaga ela do vetor puxando as proximas
// uma posicao para tras.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void cancelarSessao() {
    int id;
    int indice;
    int i;

    printf("\nDigite o ID da sessao que deseja cancelar: ");
    scanf("%d", &id);
    indice = buscarIndiceSessao(id);

    if (indice == -1) {
        printf("\n[ERRO] Sessao nao encontrada!\n");
    } else {
        printf("\nSessao %d cancelada. Valor estornado: R$ %.2f\n", id, historicoSessoes[indice].valorTotal);
        for (i = indice; i < totalSessoes - 1; i++) {
            historicoSessoes[i] = historicoSessoes[i + 1];
        }
        totalSessoes--;
    }
}

// ----------------------------------------------------------------------------
// RELATORIO: computador com mais minutos de uso somando todas as sessoes.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void relatorioComputadorMaisUsado() {
    int i, j;
    int somaMinutos;
    int maiorMinutos = 0;
    int indiceMaior = -1; // -1 = ainda nao achou nenhum

    // para cada computador, soma os minutos de todas as sessoes dele
    for (i = 0; i < totalComputadores; i++) {
        somaMinutos = 0;
        for (j = 0; j < totalSessoes; j++) {
            if (historicoSessoes[j].idComputadorSessao == listaComputadores[i].idComputador) {
                somaMinutos = somaMinutos + historicoSessoes[j].minutosUsados;
            }
        }
        // se esse computador passou o maior ate agora, ele vira o novo maior
        if (somaMinutos > maiorMinutos) {
            maiorMinutos = somaMinutos;
            indiceMaior = i;
        }
    }

    printf("\n--- RELATORIO: COMPUTADOR MAIS UTILIZADO ---\n");
    if (indiceMaior == -1) {
        printf("Nenhuma sessao registrada ainda.\n");
    } else {
        printf("Computador: %s (ID %d)\n", listaComputadores[indiceMaior].descricao,
               listaComputadores[indiceMaior].idComputador);
        printf("Tempo total de uso: %d minutos\n", maiorMinutos);
    }
}

// ----------------------------------------------------------------------------
// RELATORIO: cliente VIP = cliente com mais minutos de uso somando as sessoes.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void relatorioClienteVip() {
    int i, j;
    int somaMinutos;
    int maiorMinutos = 0;
    int indiceMaior = -1;

    for (i = 0; i < totalClientes; i++) {
        somaMinutos = 0;
        for (j = 0; j < totalSessoes; j++) {
            if (historicoSessoes[j].idClienteSessao == listaClientes[i].idCliente) {
                somaMinutos = somaMinutos + historicoSessoes[j].minutosUsados;
            }
        }
        if (somaMinutos > maiorMinutos) {
            maiorMinutos = somaMinutos;
            indiceMaior = i;
        }
    }

    printf("\n--- RELATORIO: CLIENTE VIP ---\n");
    if (indiceMaior == -1) {
        printf("Nenhuma sessao registrada ainda.\n");
    } else {
        printf("Cliente VIP: %s (ID %d)\n", listaClientes[indiceMaior].nome,
               listaClientes[indiceMaior].idCliente);
        printf("Tempo total de uso: %d minutos\n", maiorMinutos);
    }
}

// ----------------------------------------------------------------------------
// RELATORIO: mostra todas as sessoes de um cliente e o total gasto por ele.
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void relatorioSessoesPorCliente() {
    int id;
    int i;
    int quantidade = 0;
    float totalGasto = 0;

    printf("\nDigite o ID do cliente: ");
    scanf("%d", &id);

    printf("\n--- RELATORIO: SESSOES DO CLIENTE %d ---\n", id);
    for (i = 0; i < totalSessoes; i++) {
        if (historicoSessoes[i].idClienteSessao == id) {
            printf("Sessao %d | ID Computador: %d | %d minutos | R$ %.2f\n",
                   historicoSessoes[i].idSessao, historicoSessoes[i].idComputadorSessao,
                   historicoSessoes[i].minutosUsados, historicoSessoes[i].valorTotal);
            quantidade++;
            totalGasto = totalGasto + historicoSessoes[i].valorTotal;
        }
    }

    if (quantidade == 0) {
        printf("Nenhuma sessao encontrada para esse cliente.\n");
    } else {
        printf("Total: %d sessoes | Valor gasto: R$ %.2f\n", quantidade, totalGasto);
    }
}

// ----------------------------------------------------------------------------
// ORDENACAO: coloca as sessoes da mais cara para a mais barata (Bubble Sort).
// Autor: [Integrante D - Guilherme Henrique]
// ----------------------------------------------------------------------------
void ordenarSessoesPorValor() {
    int i, j;
    struct Sessao aux;

    for (i = 0; i < totalSessoes - 1; i++) {
        for (j = 0; j < totalSessoes - 1 - i; j++) {
            // aqui o sinal e "<" porque queremos do MAIOR para o menor
            if (historicoSessoes[j].valorTotal < historicoSessoes[j + 1].valorTotal) {
                aux = historicoSessoes[j];
                historicoSessoes[j] = historicoSessoes[j + 1];
                historicoSessoes[j + 1] = aux;
            }
        }
    }
    printf("\nSessoes ordenadas por valor (mais cara primeiro)!\n");
    listarSessoes();
}

// ----------------------------------------------------------------------------
// Submenu do Modulo 4
// Autor: [Integrante D - Guilherme Henrique Bueno, 47290391]
// ----------------------------------------------------------------------------
void moduloSessoesRelatorios() {
    int opcaoSessao;
    do {
        printf("\n--- [MODULO 4: SESSOES E RELATORIOS (Integrante D)] ---\n");
        printf("1. Registrar Nova Sessao (Cruza Cliente + Computador + Tempo)\n");
        printf("2. Listar Historico de Sessoes\n");
        printf("3. Cancelar / Estornar Sessao\n");
        printf("4. [RELATORIO] Computador Mais Utilizado\n");
        printf("5. [RELATORIO] Cliente VIP (Maior Tempo de Uso)\n");
        printf("6. [RELATORIO] Sessoes de um Cliente Especifico\n");
        printf("7. [ORDENACAO] Listar Sessoes por Valor (Maior para Menor)\n");
        printf("0. Voltar ao Menu Principal\n");
        printf("Escolha uma acao: ");
        opcaoSessao = -1; // comeca invalida: se digitarem uma letra, cai no default
        scanf("%d", &opcaoSessao);
        while (getchar() != '\n') { } // joga fora o que sobrou digitado (letras e o Enter)

        switch (opcaoSessao) {
            case 1:
                registrarSessao();
                break;
            case 2:
                listarSessoes();
                break;
            case 3:
                cancelarSessao();
                break;
            case 4:
                relatorioComputadorMaisUsado();
                break;
            case 5:
                relatorioClienteVip();
                break;
            case 6:
                relatorioSessoesPorCliente();
                break;
            case 7:
                ordenarSessoesPorValor();
                break;
            case 0:
                printf("\nRetornando ao menu principal...\n");
                break;
            default:
                printf("\n[ERRO] Opcao invalida no Modulo de Sessoes!\n");
        }
    } while (opcaoSessao != 0);
}


// ============================================================================
// PARTE 3: FUNCAO PRINCIPAL (MAIN) - DESPACHANTE DE MENUS
// Autor: [Integrante A - Alexander Guimar�es Gallotti Moreira, 47364548]
// ============================================================================
int main() {
    int opcaoPrincipal;

    do {
        exibirCabecalho();
        printf("SELECIONE A PERSPECTIVA DO SISTEMA:\n");
        printf("1. Modulo de Clientes (Integrante A)\n");
        printf("2. Modulo de Computadores (Integrante B)\n");
        printf("3. Modulo de Lanchonete / Produtos (Integrante C)\n");
        printf("4. Modulo de Sessoes e Relatorios (Integrante D)\n");
        printf("0. Encerrar o Sistema\n");
        printf("------------------------------------------------------\n");
        printf("Digite a opcao desejada: ");
        opcaoPrincipal = -1; // comeca invalida: se digitarem uma letra, cai no default
        scanf("%d", &opcaoPrincipal);
        while (getchar() != '\n') { } // joga fora o que sobrou digitado (letras e o Enter)

        switch (opcaoPrincipal) {
            case 1:
                moduloClientes();
                break;
            case 2:
                moduloComputadores();
                break;
            case 3:
                moduloProdutos();
                break;
            case 4:
                moduloSessoesRelatorios();
                break;
            case 0:
                printf("\nEncerrando o sistema Lan House Byte 2000... Ate logo!\n");
                break;
            default:
                printf("\n[ALERTA] Opcao invalida! Digite um numero de 0 a 4.\n");
        }
    } while (opcaoPrincipal != 0);

    return 0;
}
